package app.domain.stores;

import app.domain.model.ScheduleVaccine;
import app.domain.model.ScheduleVaccineSNSUser;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ScheduledSNSUserStoreTest {

    private ScheduleVaccineSNSUser SchedulevaccineA = new ScheduleVaccineSNSUser("123456789", "20/01/2012", "Masculine", "pfizer", "29/05/2022", "10:10", "Porto");


    @Test
    void createSc() {
        ScheduleVaccineStore sv = new ScheduleVaccineStore();
        String actual= String.valueOf(SchedulevaccineA);
        String expected = String.valueOf(sv.create("123456789", "20/01/2002", "Masculine", "pfizer", "29/05/2022", "10:10", "Porto"));
        Assertions.assertEquals(actual, expected);
    }

    @Test
    void validateScheduleVaccine() {
    }


}