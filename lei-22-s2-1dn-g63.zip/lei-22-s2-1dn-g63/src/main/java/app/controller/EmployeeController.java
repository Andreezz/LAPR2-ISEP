package app.controller;

import app.domain.model.Company;
import app.domain.model.Employee;
import app.domain.stores.EmployeeStore;
import pt.isep.lei.esoft.auth.AuthFacade;

/**
 * Controller of the UserStory: Register an Employee
 * @author Lourenço Mayol -> 1211206@isep.ipp.pt
 */

public class EmployeeController
{
    private Company company;
    private EmployeeStore store;
    private AuthFacade auth;
    private Employee employee;

    /**
     * gets instances of the class Company, AuthFacade and EmployeeStore
     */
    public EmployeeController() {
        this.company = App.getInstance().getCompany();
        this.store = company.getEmployeeStore();
        this.auth = company.getAuthFacade();
    }

    /**
     * creates an instance of the classe employee using the method createEmployee() from the EmployeeStore class
     */
    public void createEmployee(String address , String name, String phoneNumber, String email, String cc){
        employee = store.createEmployee(address , name, phoneNumber, email, cc);
    }

    /**
     * @param roleId represents the employee's role
     * @param pwd represents the employee's password (it is generated automatically by the system)
     * uses the methods validateEmployee() and employeeExists from the EmployeeStore class to verify if the employee is valid
     * if the employee is valid it will register the employee, creating a user in the system for him and saving the employee in the employees list
     * @return true if the employee was registered, otherwise, returns false
     */
    public boolean saveEmployee(String roleId, String pwd){
        if(store.validateEmployee(employee) && !(store.employeeExists(employee))){
            store.saveEmployee(this.employee);
            auth.addUserWithRole(this.employee.getName(),String.valueOf(this.employee.getEmail()),pwd,  roleId);
            return true;
        }
        else return false;
    }

    /**
     * @return a String containing an employee's information by accessing the method getEmployeeInfo() of the EmployeeStore class
     */
    public String getEmployeeInfo(){return store.getEmployeeInfo();}

    /**
     * clears the employees list using the method of the same name from the EmployeeStore class
     */
    public void clearEmployeeList(){store.clearEmployeeList();}

    /**
     * @return the information of all the employee's that are in the employees list by accessing the method of the same name from the class EmployeeStore
     */
    public String getEmployeesList(){return store.getEmployeesList();}

}
