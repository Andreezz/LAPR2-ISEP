package app.domain.stores;


import app.domain.model.*;
import app.domain.model.ScheduleVaccineSNSUser;

import app.domain.model.NewVaccine;
import app.domain.model.VaccinationCenter;

import java.util.ArrayList;
import java.util.List;



public class ScheduledSNSUserStore {

    private List<ScheduleVaccineSNSUser> scheduledvacc;
    private ScheduleVaccineSNSUser scheduledvaccine;
    private List<NewVaccine> NVs;
    private NewVaccine NV;
    private List<VaccinationCenter> VCs;
    private VaccinationCenter VC;


    public ScheduledSNSUserStore(){
        this.scheduledvacc = new ArrayList<>();
    }

    /**
     *
     *Creates the vaccine
     * @param number
     * @param age the sns user age
     * @param gender the sns user gender
     * @param vaccine the vaccine that the sns user intends to take
     * @param date the day that the sns user intends to take the vaccine shot
     * @param hours the time that the sns user intends to take the vaccine shot
     * @param NameCenter  the vaccination center that the user intends to be vaccinated on
     * @return the vaccine
     */
    public ScheduleVaccineSNSUser createSc(String number, String age, String gender, String vaccine, String date, String hours, String NameCenter){
        return this.scheduledvaccine = new ScheduleVaccineSNSUser (number, age, gender, vaccine, date, hours, NameCenter);
    }

    /**
     * Checks if there are any existing vaccines
     * @param scheduledvaccine
     * @return a logical value of true or false
     */
    public boolean ValidateScheduleVaccine( ScheduleVaccineSNSUser scheduledvaccine) {
        if (scheduledvaccine == null || contains(scheduledvaccine)) {
            return false;
        }
        return true;
    }

    /**
     * Checks if the vaccine already exists or not
     * @param schedule
     * @return a logical value and affirms if the vaccine is already registered
     */
    public boolean ScheduledCheck(ScheduleVaccineSNSUser schedule){
        for(ScheduleVaccineSNSUser s : scheduledvacc){
            if(s.equals(schedule))
                throw new IllegalArgumentException("This schedule already exist");
            return true;
        }
        return false;
    }

    /**
     * Function that gives you the scheduled vaccine´s list
     * @return the scheduled vaccine´s list
     */
    public String getScheduledVaccineList(){
        StringBuilder scheduleList = new StringBuilder();
        for (ScheduleVaccineSNSUser s : scheduledvacc) {
            scheduleList.append(s.toString());
            scheduleList.append("\n");
        }
        return String.valueOf(scheduleList);
    }

    /**
     * Deletes the vaccine´s list
     */
    public void clearSchedulesSNS(){
        scheduledvacc.clear();
    }
    public String getScheduledList(){
        StringBuilder scheduleList = new StringBuilder();
        for (ScheduleVaccineSNSUser s : scheduledvacc) {
            scheduleList.append(s.toString());
            scheduleList.append("\n");
        }
        return String.valueOf(scheduleList);
    }

    /**
     * Gets the scheduled vaccine´s information
     * @return the info related to a schedule
     */
    public String getScheduledVaccineinfo(){
        return this.scheduledvaccine.toString();
    }

    /**
     * gets the scheduled vaccine
     * @return a specific vaccine
     */
    public ScheduleVaccineSNSUser getScheduledvaccine(){
        return scheduledvaccine;
    }


    public void RemoveSchedulevacc(int g){scheduledvacc.remove(g-1);}



    public boolean contains(ScheduleVaccineSNSUser scheduledvaccine) {
        if (this.scheduledvacc.contains(scheduledvaccine)) {
            return true;
        } else {
            return false;
        }
    }
    public boolean add(ScheduleVaccineSNSUser scheduledvaccine) {
        scheduledvacc.add(scheduledvaccine);
        return true;
    }

    public void saveNewScheduledVaccine(ScheduleVaccineSNSUser scheduledvaccine){
        scheduledvacc.add(scheduledvaccine);
    }
    public List<NewVaccine> getList() {
        return this.NVs;
    }

    public List<VaccinationCenter> getListt(){return  this.VCs;}
}
