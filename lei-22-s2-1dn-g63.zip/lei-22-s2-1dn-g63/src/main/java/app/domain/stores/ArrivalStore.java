package app.domain.stores;

import app.domain.model.Arrival;
import app.domain.model.SNSUser;
import app.domain.model.VaccinationCenter;

import java.time.LocalDate;
import java.util.*;

/**
 * Store of the UserStory: Register arrival of SNS user
 * @author Pedro Ferreira -> 1210825@isep.ipp.pt
 */

public class ArrivalStore {

    private Set<Arrival> store = new HashSet<>();

    public ArrivalStore() { }

    public boolean addArrival( Arrival arrival ) {
        return arrival != null && !this.exists(arrival) ? this.store.add(arrival) : false;
    }

    public Arrival createArrival(SNSUser snsNum, VaccinationCenter centerName, String date, String time ) {
        return new Arrival(snsNum, centerName, date, time);
    }

    public boolean validateArrival( Arrival arrival ) {
        try {
            return arrival.checkTimeFormat(arrival.getTime()) && !checkDuplicates(arrival);
        }catch(Exception e) {
            System.err.println("Error 400 : Arrival data failed validation!");
        }
        throw new IllegalArgumentException("ducks");
    }

    public boolean checkDuplicates( Arrival arrival ) {
        for( Arrival i : store ) {
            if( arrival.hasSNSnumber(i.getUser()) && arrival.hasDate(i.getDate())  ) {
                return true;
            }
        }
        return false;
    }

    public boolean saveArrival( Arrival arrival ) {
        if(validateArrival(arrival) ) {
            addArrival(arrival);
            return true;
        }
        return false;
    }

    public boolean exists(Arrival arrival) {
        return this.store.contains(arrival);
    }

    /**
     *
     * @param vc Vaccination Centre the Nurse logged in works at
     * @return list of Arrivals in the defined vaccination centre
     */
    public ArrivalStore filterByVaccCentre(String vc){
        ArrivalStore list = new ArrivalStore();
        for(Arrival arr : store){
            if(Objects.equals(arr.getVaccCenter().getName(), vc)){
                list.addArrival(arr);
            }
        }
        return list;
    }

    /**
     *
     * @return the list ordered by time of arrival
     */
    public ArrivalStore orderByArrival(){
        List<Arrival> list = new ArrayList<>(this.store);
        list.sort(Comparator.comparing(Arrival::getTime));
        ArrivalStore ret = new ArrivalStore();
        for(Arrival arr : list) {
            if (Objects.equals(arr.getDate(), String.valueOf(LocalDate.now()))) {
                ret.addArrival(arr);
            }
        }
        return ret;
    }

    /**
     *
     * @return if the ArrivalStore if empty or not
     */
    public boolean isEmpty(){return this.store.size() == 0;}

    /**
     * Prints the list
     */
    public void print() {
        List<Arrival> list = new ArrayList<>(this.store);
        for(Arrival a : list){
            System.out.println(a.toString());
        }
    }


}
