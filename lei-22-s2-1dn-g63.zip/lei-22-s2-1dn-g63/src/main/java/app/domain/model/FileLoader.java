package app.domain.model;

import app.controller.FileLoaderController;
import app.domain.shared.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.commons.io.FilenameUtils;

/**
 * Main class of the UserStory: As, an administrator, load a set of SNS users from a CSV file
 * @author Lourenço Mayol -> 1211206@isep.ipp.pt
 */
public class FileLoader {

    private File SNSUserfile;
    private Scanner sc;
    private FileLoaderController ctrl;
    private List<SNSUser> fileUsers;

    /**
     * Creates: an instance of the class FileLoaderController, a list of SNS Users, a File and a file Scanner
     * @param filePath is the path of the file, this is checked for errors if this is correct an intance of the File is creted with the specified path
     */
    public FileLoader(String filePath) {
        try {
            if (checkFilePath(filePath)) {
                ctrl = new FileLoaderController();
                fileUsers = new ArrayList<>();
                SNSUserfile = new File(filePath);
                sc = new Scanner(SNSUserfile);
            } else {
                System.out.println("File format is wrong!");
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    /** Determines the file type of the CSV file and loads the file, adding them to a list that will be forwarded to the controller
     * @return true if the file is valid, otherwise, returns false
     */
    public boolean loadFile() {
        boolean firstLineShouldBeLoaded = false;
        String line, firstLine = null;
        String delimiter = null;
        try {
            if(sc.hasNextLine()){
                firstLine = sc.nextLine();
                if (firstLine.contains(",")) {
                    delimiter = ",";
                    firstLineShouldBeLoaded = true;
                } else {
                    if (!firstLine.contains(";")) {
                        delimiter = ";";
                    }
                }
            }
            if(firstLineShouldBeLoaded)
                loadSNSUser(delimiter, firstLine);
            while (sc.hasNextLine()) {
                line = sc.nextLine();
                loadSNSUser(delimiter, line);
            }
            sc.close();
            ctrl.loadSNSUserSet(fileUsers);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Checks a file's path
     * @param filePath a String that represents the file's path
     * @return true if the file is a csv type and the file's path is not blank, otherwise, returns false
     */
    public boolean checkFilePath(String filePath) {
        try {
            String check = FilenameUtils.getExtension(filePath);
            if (check.equals("csv")) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /** Loads a single SNS user if this is valid by adding it to a list of users
     * @param delimiter is the delimiter used to separate the file's items
     * @param line it is a line of the file
     */
    public void loadSNSUser(String delimiter, String line){
        String[] userAttributes;
        userAttributes = line.split(delimiter);
        if (userAttributes[0].equals(line)) {
            throw new IllegalArgumentException("File's content is in the wrong format!");
        }
        if (userAttributes.length == Constants.SNS_USER_ATTRIBUTES) {
            SNSUser user = ctrl.getUser(userAttributes[0], userAttributes[1], userAttributes[2], userAttributes[3], userAttributes[4], userAttributes[5], userAttributes[6], userAttributes[7]);
            if (!ctrl.fileUserExists(user)) {
                if (ctrl.validateFileUser(user)) {
                    fileUsers.add(user);
                }
            }
        } else {
            throw new IllegalArgumentException("All the SNS user attributes must be in each line of the file!\nPlease note that there are 8 attributes!\nAddresses must not contain commas or semicolons!");
        }
    }
}
