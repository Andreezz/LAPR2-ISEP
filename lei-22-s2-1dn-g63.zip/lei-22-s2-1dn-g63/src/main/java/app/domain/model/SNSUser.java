package app.domain.model;

import app.domain.shared.Constants;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.math.NumberUtils;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * SNSUser class for the UserStory: Register an SNS User, as a Receptionist
 * @author Lourenço Mayol -> 1211206@isep.ipp.pt
 */
public class SNSUser {

    /** These attributes represent an SNS user
     */
    private String name;
    private String address;
    private String gender;
    private String phoneNumber;
    private String email;
    private String birthDate;
    private String SNSNumber;
    private String cc;

    /**
     * Creates an SNS user with the specified information. If any attribute is null then an exception will be activated.
     * Gender is specified by the user
     * @param name represents the SNS user's name
     * @param address represents the SNS user's address
     * @param gender represents the SNS user's gender
     * @param phoneNumber represents the SNS user's phone number
     * @param email represents the SNS user's email
     * @param birthdate represents the SNS user's birthdate
     * @param SNSNumber represents the SNS user's number
     * @param cc represents the SNS user's citizen card number
     */
    public SNSUser(String name, String gender, String birthdate, String address, String phoneNumber, String email, String SNSNumber, String cc){
        if(ObjectUtils.allNotNull(name, address, gender, phoneNumber, email, birthdate, SNSNumber, cc)) {
            this.name = name;
            this.address = address;
            this.gender = gender;
            this.phoneNumber = phoneNumber;
            this.email = email;
            this.birthDate = birthdate;
            this.SNSNumber = SNSNumber;
            this.cc = cc;
        }
        else
            throw new IllegalArgumentException("SNSUser cannot have null attributes!");
    }

    /** Gets the user's name
     * @return a String representing the user's name
     */
    public String getName() {
        return name;
    }

    /** Gets the user's address
     * @return a String representing the user's address
     */
    public String getAddress() {
        return address;
    }

    /** Gets the user's gender
     * @return a String representing the user's gender
     */
    public String getGender() {
        return gender;
    }

    /** Gets the user's phone number
     * @return a String representing the user's phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /** Gets the user's e-amail
     * @return a String representing the user's e-mail
     */
    public String getEmail() {
        return email;
    }

    /** Gets the user's birthdate
     * @return a String representing the user's birthdate
     */
    public String getBirthDate() {
        return birthDate;
    }

    /** Gets the user's phone number
     * @return a String representing the user's phone number
     */
    public String getSNSNumber() {
        return SNSNumber;
    }

    /** Gets the user's citizen card
     * @return a String representing the user's civil id
     */
    public String getCC() {
        return cc;
    }

    /**
     * @param phoneNumber represents the phone number to be checked
     * The phone number is valid if this follows these rules:
     * phone number must have 12 characters (inculding portuguese prefix)
     * all of the characters in the phone number must be digits
     * if the prefix is 351 and the indicative is 91, 93 or 96
     * @return true if the phone number is valid
     */
    public boolean checkPhoneNumberFormat (String phoneNumber){
        int numberDigits = phoneNumber.length();
        //check number of digits
        if (numberDigits != Constants.PHONE_NUMBER_DIGITS) {
            throw new IllegalArgumentException("Phonenumber must have 9 digits!");
        }
        //check String is a number
        else {
            if (!NumberUtils.isDigits(phoneNumber))
                throw new IllegalArgumentException("All the characters in the phone number must be digits! Symbols or letters are not valid!");
            else {
                String indicative = String.valueOf(phoneNumber.charAt(0)) + String.valueOf(phoneNumber.charAt(1));
                if (!((indicative.equals("93") || indicative.equals("91") || indicative.equals("96"))))
                    throw new IllegalArgumentException("Phone number indicative must be 91 or 93 or 96!");
            }
        }
        return true;
    }

    /**
     * @param email represents the email to be checked
     * the email is valid if this follows the correct format for e-mails. Its parts must be separated by dots and it must have an at sign.
     * @return true if the e-mail is valid otherwise, it will return false
     */
    public boolean checkEmailFormat(String email){
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }

    /**
     * @param cc represents the cc to be checked
     * Considering that the cc is separated in 3 parts, it is valid if this follows these rules:
     * the cc must have 14 characters inculding the signs (-) that separate its parts
     * the first and second part must only contain digits
     * the 3 parts must be separated by - sign
     * the two first characters in the third part must be uppercase letters and the last character must be a digit
     * @return true if the cc is valid
     */
    public boolean checkCCFormat(String cc){
        //check number of characters
        if(cc.length() != Constants.CC_NUMBER_CHAR)
            throw new IllegalArgumentException("cc format 11111111-1-AA1 must have 14 characters!");
        else{
            //check format
            String check = String.valueOf(cc.charAt(8)) + String.valueOf(cc.charAt(10));
            if (!check.equals("--")){
                throw new IllegalArgumentException("cc must be written in the following format: 11111111-1-AA1");
            }
            else{
                String[] ccParts = cc.split("-");
                if(!(NumberUtils.isDigits(ccParts[0]) && NumberUtils.isDigits(ccParts[1]) && NumberUtils.isDigits(String.valueOf(ccParts[2].charAt(2)))))
                    throw new IllegalArgumentException("cc must be written in the following format: 11111111-1-AA1 (1 represents a digit)");
                else {
                    for (int i = 0; i < 2; i++) {
                        char c = ccParts[2].charAt(i);
                        if (!(c >= 'A' && c <= 'Z')) {
                            throw new IllegalArgumentException("cc must be written in the following format: 11111111-1-AA1 (A represents an uppercase letter)");
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * @param name represents the name to be checked
     * the name is valid if it only contains letters (ç is not valid).
     * @return true if the name is valid
     */
    public boolean checkNameFormat(String name){
        String [] nameParts = name.split(" ");
        for (int i = 0; i < nameParts.length; i++)
        {
            if (!nameParts[i].matches("[a-zA-ZáàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ']+")) {
                throw new IllegalArgumentException("SNS user's name must contain only letters! (ç is not accepted)");
            }
        }
        return true;
    }

    public boolean checkGenderFormat(String gender){
        if (!gender.matches("[a-zA-Z/]+")) {
            throw new IllegalArgumentException("The SNS user's gender must contain only letters!");
        }
        return true;
    }

    /** Determines if an SNS number is valid, it will be valid if it has 9 characters that are digits
     * @param SNSNumber represents the SNS number to be checked
     * @return
     */
    public boolean checkSNSNumber(String SNSNumber){
        String SNSNumberRegex = "^[0-9]{9}$";
        Pattern pattern = Pattern.compile(SNSNumberRegex);
        if(!pattern.matcher(SNSNumber).matches()){
            throw new IllegalArgumentException("SNS number must have 9 characters and can only contain digits!");
        }
        return true;
    }

    @Override
    public String toString() {
        return "SNSUser{" + "\n" +
                "name=" + name + "\n" +
                "address=" + address + "\n" +
                "gender=" + gender + "\n" +
                "phoneNumber=" + phoneNumber + "\n" +
                "email=" + email + "\n" +
                "birthDate=" + birthDate + "\n" +
                "SNSNumber=" + SNSNumber + "\n" +
                "cc=" + cc + "\n" +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SNSUser)) return false;
        SNSUser snsUser = (SNSUser) o;
        return name.equals(snsUser.name) || address.equals(snsUser.address) || phoneNumber.equals(snsUser.phoneNumber) || email.equals(snsUser.email) || SNSNumber.equals(snsUser.SNSNumber) || cc.equals(snsUser.cc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, phoneNumber, email, SNSNumber, cc);
    }
}
