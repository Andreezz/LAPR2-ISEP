package app.domain.model;

import app.domain.stores.*;
import pt.isep.lei.esoft.auth.AuthFacade;
import org.apache.commons.lang3.StringUtils;
import pt.isep.lei.esoft.auth.mappers.dto.UserDTO;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paulo Maio <pam@isep.ipp.pt>
 */
public class Company {

    private ArrivalStore arrStore;
    private EmployeeStore employeeStore;
    private VaccinationCenterStore vaccinationCenterList;
    private VaccineTypeStore vtstore;
    private VaccineStore vaccineStore;
    private String designation;
    private AuthFacade authFacade;
    private SNSUserStore userStore;
    private ScheduleVaccineStore scheduleStore;
    private ScheduledSNSUserStore scheduledstore;



    public Company(String designation)
    {
        if (StringUtils.isBlank(designation))
            throw new IllegalArgumentException("Designation cannot be blank.");

        this.designation = designation;
        this.authFacade = new AuthFacade();
        this.vaccinationCenterList = new VaccinationCenterStore();
        this.vtstore= new VaccineTypeStore();
        this.employeeStore = new EmployeeStore();
        this.vaccineStore = new VaccineStore();
        this.arrStore = new ArrivalStore();
        this.userStore = new SNSUserStore();
        this.scheduledstore= new ScheduledSNSUserStore();
        this.scheduleStore = new ScheduleVaccineStore();
    }

    public String getDesignation() {
        return designation;
    }

    public AuthFacade getAuthFacade() {
        return authFacade;
    }

    /**
     * @return the list of Vaccination Centers in the System
     */
    public VaccinationCenterStore getVaccinationCenterList() {
        return this.vaccinationCenterList;
    }
    /**
     * @return the list of Vaccine types in the System
     */
    public VaccineTypeStore getVaccinetypeList(){return  this.vtstore;}

    /**
     * @return an instance of the class EmployeeStore
     */
    public EmployeeStore getEmployeeStore(){return this.employeeStore;}

    /**
     * @return the list of currently registered vaccines and its properties
     */
    public VaccineStore getVaccineStore(){return this.vaccineStore;}

    public ArrivalStore getArrivalStore() { return this.arrStore; }

    /**
     * @return an instance of the class SNSUserStore
     */
    public SNSUserStore getSNSUserStore(){return this.userStore;}

    public ScheduleVaccineStore getScheduleStore() {
        return this.scheduleStore;
    }

    public ScheduledSNSUserStore getScheduledStore(){return this.scheduledstore;}

    /**
     *
     * @param roleID role intended for the list of employees
     * @return list of users with the intended role
     */
    public List<String> getAllwithRole(String roleID) {
        List<String> ids = new ArrayList<>();
        List<UserDTO> users= this.authFacade.getUsersWithRole(roleID);
        for(UserDTO user: users){
            ids.add(user.getId());
        }
        return ids;
    }




}
