package app.domain.model;

public class Schedule {

    private String openHours;
    private String closeHours;

    public Schedule(String openHours, String closeHours) {
        this.openHours = openHours;
        this.closeHours = closeHours;
    }

    public String getOpenHours() {
        return openHours;
    }

    public String getCloseHours() {
        return closeHours;
    }
}
