package app.ui;

import app.ui.console.MainMenuUI;
import at.favre.lib.crypto.bcrypt.BCrypt;
import pt.isep.lei.esoft.auth.domain.model.Email;
import pt.isep.lei.esoft.auth.domain.model.Password;
import pt.isep.lei.esoft.auth.domain.model.User;
import pt.isep.lei.esoft.auth.domain.model.UserRole;

import static app.domain.shared.Constants.ROLE_ADMIN;

/**
 *
 * @author Paulo Maio <pam@isep.ipp.pt>
 */


public class Main {

    public static void main(String[] args)
    {

        try
        {
            MainMenuUI menu = new MainMenuUI();

            menu.run();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
