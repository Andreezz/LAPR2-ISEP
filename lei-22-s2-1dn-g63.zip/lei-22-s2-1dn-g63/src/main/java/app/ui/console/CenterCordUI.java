package app.ui.console;

import app.ui.console.utils.Utils;

import java.util.ArrayList;
import java.util.List;


/**
 * UserInterface of Receptionist
 *
 * @author André Gonçalves -> 1210804@isep.ipp.pt
 */

public class CenterCordUI implements Runnable {

    public CenterCordUI() {
    }

    @Override
    public void run() {

        List<MenuItem> options = new ArrayList<MenuItem>();

        options.add(new MenuItem("List all vaccines.", new ListVaccinesUI()));
       
        int option = 0;

        do {
            option = Utils.showAndSelectIndex(options, "\n\nCenter Cordinator Menu:");
            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}
