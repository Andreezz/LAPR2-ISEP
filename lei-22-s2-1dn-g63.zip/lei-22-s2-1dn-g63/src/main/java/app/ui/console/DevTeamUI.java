package app.ui.console;


public class DevTeamUI implements Runnable{

    public DevTeamUI()
    {

    }
    public void run()
    {
        System.out.println("\n");
        System.out.printf("Development Team:\n");
        System.out.println("\t-----------------------------------------");
        System.out.printf("\t André Gonçalves - 1210804@isep.ipp.pt \n");
        System.out.printf("\t Lourenço Mayol - 1211206@isep.ipp.pt \n");
        System.out.printf("\t Miguel Moreira - 1211240@isep.ipp.pt \n");
        System.out.printf("\t Petra Conceição - 1201614@isep.ipp.pt \n");
        System.out.printf("\t Pedro Ferreira - 1210825@isep.ipp.pt \n");
        System.out.println("\t-----------------------------------------");
        System.out.println("\n");
    }
}
