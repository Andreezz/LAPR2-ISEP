# Use Case Diagram (UCD)

![Use Case Diagram]

![](UCD.svg)


