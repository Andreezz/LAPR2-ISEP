# Glossary

Project-Based Learning (PBL) model | 
Project | 
DGS | state-funded Portuguese healthcare system
vaccination process | 
Terms, Expressions and Acronyms (TEA) must be organized alphabetically.

(To complete according the provided example)

| TEA (EN)  | TEA (PT) | Description (EN)                                           |
|:------------------------|:-----------------|:--------------------------------------------|
| Clerk | Administrativo | Person responsible for carrying out various business supporting activities on the system. |
| CLK | ADM | Acronym for Clerk.|
| ... | ... | ...|







